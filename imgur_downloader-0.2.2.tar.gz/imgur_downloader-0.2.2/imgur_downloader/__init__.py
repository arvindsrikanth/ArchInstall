from .imgurdownloader import ImgurDownloader  # NOQA
# defining __version__ variable is pointless
__author__ = 'Alex Gisby <alex@solution10.com>'
__all__ = []
